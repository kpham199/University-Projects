// gameboard.h
//
// GameBoard class starter code for course project
// University of Illinois at Chicago
// CS 211 - Programming Practicum
// Original Author: Professor Scott Reckinger
//

#ifndef _GAMEBOARD_H
#define _GAMEBOARD_H

#include <cstdlib>
#include <iostream>
#include <string>
#include <ctime>
#include <stdexcept>

#include "boardcell.h"
#include "grid.h"

using namespace std;

class GameBoard {
	private: 
	    Grid<BoardCell*> board;
        size_t numRows;
        size_t numCols;
        int numFire;
        int numWater;
        int numWall;
        int numGrass;
        int numEmpty;
        
	public: 
		/* default constructor */
        GameBoard() {
            numFire = 10;
            numWater = 20;
            numWall = 0;
            numGrass = 15*40-30;
            numEmpty = 0;
            
            this -> numRows = 15;
            this -> numCols = 40;
            
            Grid<BoardCell*> boardnew(numRows, numCols);
            board = boardnew;
            
            blankBoard();
        }
        
        /* param constructor */
        GameBoard(size_t numRows, size_t numCols) {
            numFire = 10;
            numWater = 20;
            numWall = 0;
            numGrass = numRows*numCols-30;
            numEmpty = 0;
            
            this -> numRows = numRows;
            this -> numCols = numCols;
            
            Grid<BoardCell*> boardnew(numRows, numCols);
            board = boardnew;
            
            blankBoard();
        }
        
        /* destructor */
        virtual ~GameBoard() {
            for (size_t row = 0; row < board.numrows(); row++) {
                for (size_t col = 0; col < board.numcols(row); col++) {
                    delete board(row, col);
                }
            }
        }

        void blankBoard() {
            for (size_t row = 0; row < board.numrows(); row++) {
                for (size_t col = 0; col < board.numcols(row); col++) {
                    board(row, col) = new Grass(row,col);
                }
            }
        }

        char getCellDisplay(size_t r, size_t c) {
            return board(r,c)->display();
        }

        void setCell(BoardCell* myCell, size_t r, size_t c) {
            board(r,c) = myCell;
        }
    
        void freeCell(size_t r, size_t c) {
            delete board(r,c);
        }

        // fills the board with by randomly placing...
        //  - numFire Fire (*) cells in the first three columns
        //  - 3 vertical Walls (x), each 1/2 of board height, not in the first three columns
        //  - numWater Water (~) cells to the right of the first three columns
        //  - the remaining cells are all Grass cells (,)
        void setupBoard(int seed) {
            srand(seed);
            size_t r,c;

            for (int i = 0; i < numFire; i++) {
                r = rand() % numRows;
                c = rand() % 3;
                while (board(r,c)->display() != ',') {
                    r = rand() % numRows;
                    c = rand() % 3;
                }
                delete board(r,c);
                board(r,c) = new Fire(r,c);
            }

            int sizeMid = numCols - 6;
            c = 3 + (rand() % sizeMid);
            for (r = 0; r < numRows/2; ++r) {
                delete board(r,c);
                board(r,c) = new Wall(r,c);
                numWall++;
            }
            size_t topc = c;

            while (c == topc || c == topc-1 || c == topc+1) {
                c = 3 + (rand() % sizeMid);
            }
            for (r = numRows-1; r > numRows/2; --r) {
                delete board(r,c);
                board(r,c) = new Wall(r,c);  
                numWall++;
            }
            size_t botc = c;

            while (c == topc || c == topc-1 || c == topc+1 || c == botc || c == botc-1 || c == botc+1) {
                c = 3 + (rand() % sizeMid);
            }
            for (r = numRows/4; r < 3*numRows/4; ++r) {
                delete board(r,c);
                board(r,c) = new Wall(r,c);
                numWall++;
            }

            for (int i = 0; i < numWater; i++) {
                r = rand() % numRows;
                c = rand() % (numCols-3)+3;
                while (board(r,c)->display() != ',') {
                    r = rand() % numRows;
                    c = rand() % (numCols-3)+3;
                }
                delete board(r,c);
                board(r,c) = new Water(r,c);
            }

            numGrass = numRows*numCols - numFire - numWater - numWall;
            
        }

        // important setters and getters
        void setNumFire(int num) {numFire = num;}
        void setNumWater(int num) {numWater = num;}
        void setNumWall(int num) {numWall = num;}
        void setNumGrass(int num) {numGrass = num;}
        void setNumEmpty(int num) {numEmpty = num;}
        int getNumFire() {return numFire;}
        int getNumWater() {return numWater;}
        int getNumWall() {return numWall;}
        int getNumGrass() {return numGrass;}
        int getNumEmpty() {return numEmpty;}
        size_t getNumRows() {return numRows;}
        size_t getNumCols() {return numCols;}

        // neatly displaying the game board, with cell counts 
		void displayBoard(bool printCounts) {
            cout << '-';
            for (size_t col = 0; col < board.numcols(0); col++) {
                cout << '-';
            }
            cout << '-';
            cout << endl;
            for (size_t row = 0; row < board.numrows(); row++) {
                cout << '|';
                for (size_t col = 0; col < board.numcols(row); col++) {
                    cout << board(row,col)->display();
                }
                cout << '|';
                cout << endl;
            }
            cout << '-';
            for (size_t col = 0; col < board.numcols(0); col++) {
                cout << '-';
            }
            cout << '-';
            cout << endl;
            
            if (printCounts) {
                cout << "# of Fire  * cells: " << numFire << endl;
                cout << "# of Water ~ cells: " << numWater << endl;
                cout << "# of Empty   cells: " << numEmpty << endl;
                cout << "# of Grass , cells: " << numGrass << endl;
                cout << "# of Wall  x cells: " << numWall << endl;
                cout << "# of ALL gridcells: " << numRows*numCols << endl;
            }
        }

        
        //---------------------------------------------------------------------------------
        // void spreadFire(char windDir) 
        // 
        // This is phase 1 of the primary gameplay operation for a single round of the game. 
        // General steps:
        //  - the input is the wind direction for the Fire spread during this round 
        //  - BEFORE attempting to spread Fire...
        //      - make sure the wind direction data member is updated for the Fire cells
        //  - For each Fire cell on the game board (NOT newly spread during this round)...
        //      - determine the cell indices where the Fire attempts to spread into
        //      - spread the Fire, catching/resolving any potential collision exceptions...
        //          - attempted spread out-of-bounds: change col &/or row to stay on board
        //          - attempted spread into Wall: change col &/or row to stay off Wall
        //          - attempted spread into Empty: change col &/or row to stay off Empty
        //          - attempted spread into Grass: replace the Grass with a new Fire cell
        //          - attempted spread into Water: replace the Water with a new Empty cell
        //
        // Important considerations: 
        //  - each Fire cell can only spread once during a single call to spreadFire()
        //      - reset newSpread to false for ALL cells before attempting to spread 
        //      - when Fire is spread, update newSpread to true for the new Fire cell
        //      - check newSpread for each Fire cell before attempting to spread Fire
        //  - BEFORE attempting to spread Fire, update windDir for Fire cells
        //  - construct BoardCell derived class objects with accurate myRow and myCol 
        //  - Fire spreading requires constructing and/or destructing objects
        //      - be careful with memory management for all BoardCell derived class objects
        //      - delete memory when you are done with a Boardcell dervied class object
        //---------------------------------------------------------------------------------
        void spreadFire(char windDir) {
            for (size_t r = 0; r < this->numRows; ++r) {
                for (size_t c = 0; c < this->numCols; ++c) {
                    board(r, c)->setNewSpread(false);
                    if (board(r,c)->isFire()) {
                        board(r, c)->setWind(windDir);
                    }
                }
            }


            for (size_t r = 0; r < this->numRows; ++r) {
                for (size_t c = 0; c < this->numCols; ++c) {
                    if (board(r, c)->isFire()) {
                        if (board(r, c)->getNewSpread() == false) {
                            size_t newR, newC;
                            board(r, c)->attemptSpreadTo(newR, newC);


                            try {       // Exception handling for invalid attempted column.
                                if (newC >= this->numCols) {
                                    throw runtime_error("Attempting to spread Fire to an out-of-bounds column");
                                }
                            }
                            catch (runtime_error& excpt) {
                                newC = c;
                            }


                            try {       // Exception handling for invalid attempted row.
                                if (newR >= this->numRows) {
                                    throw runtime_error("Attempting to spread Fire to an out-of-bounds row");
                                }
                            }
                            catch (runtime_error& excpt) {
                                newR = r;
                            }


                            try {       // Exception handling for attempting to spread fire into a Wall or Empty cell.
                                if (board(newR, newC)->isWall() || board(newR, newC)->isEmpty()) {
                                    throw runtime_error("Attempting to spread Fire to a Wall or Empty cell");
                                }
                            }
                            catch (runtime_error& excpt) {
                                if ((board(newR, c)->isWall() == false) && (board(newR, c)->isEmpty() == false)) {
                                    newC = c;
                                } else if ((board(r, newC)->isWall() == false) && (board(r, newC)->isEmpty() == false)) {
                                    newR = r;
                                    continue;
                                } else {
                                    newR = r;
                                    newC = c;
                                }
                            }


                            // Go to the next iteration/cell if newR and newC do not change.
                            if (newR == r && newC == c) {
                                continue;
                            }


                            // Below are for cases where the attempted position is at a Water or Grass cell.


                            if (board(newR, newC)->isWater()) {
                                delete board(newR, newC);       // Deletes the old cell.
                                board(newR, newC) = new Empty(newR, newC);       // Assigns a cell to be Empty. Water + Fire = Empty cell.
                                board(newR, newC)->setNewSpread(true);
                                this->numEmpty++;
                                this->numWater--;
                                continue;
                            }


                            // If (newR, newC) is a Grass cell.
                            if (board(newR, newC)->isGrass()) {
                                delete board(newR, newC);       // Deletes the old cell.
                                board(newR, newC) = new Fire(newR, newC);       // Assigns a cell to be Fire.
                                board(newR, newC)->setNewSpread(true);
                                this->numGrass--;
                                this->numFire++;
                            }
                        }
                    }
                }
            }
        }
            void spreadWater() {
            // Sets newSpread boolean to false for all cells before making any updates.
            for (size_t r = 0; r < this->numRows; ++r) {
                for (size_t c = 0; c < this->numCols; ++c) {
                    board(r, c)->setNewSpread(false);
                }
            }
           
            for (size_t r = 0; r < this->numRows; ++r) {
                for (size_t c = 0; c < this->numCols; ++c) {
                    if (board(r, c)->isWater()) {
                        if (board(r, c)->getNewSpread() == false) {
                            size_t newR, newC;
                            board(r, c)->attemptSpreadTo(newR, newC);


                            try {       // Exception handling for invalid attempted column.
                                if (newC >= this->numCols) {
                                    throw runtime_error("Attempting to spread Water to an out-of-bounds column");
                                }
                            }
                            catch (runtime_error& excpt) {
                                newC = c;
                            }


                            try {       // Exception handling for invalid attempted row.
                                if (newR >= this->numRows) {
                                    throw runtime_error("Attempting to spread Water to an out-of-bounds row");
                                }
                            }
                            catch (runtime_error& excpt) {
                                newR = r;
                            }


                            try {       // Exception handling for attempting to spread water into a Wall or Grass Cell.
                                if (board(newR, newC)->isWall() || board(newR, newC)->isGrass()) {
                                    throw runtime_error("Attempting to spread Water to a Wall or Grass cell");
                                }
                            }
                            catch (runtime_error& excpt) {
                                if ((board(newR, c)->isWall() == false) && (board(newR, c)->isGrass() == false)) {
                                    newC = c;
                                } else if ((board(r, newC)->isWall() == false) && (board(r, newC)->isGrass() == false)) {
                                    newR = r;
                                    continue;
                                } else {
                                    newR = r;
                                    newC = c;
                                }
                            }


                            // Go to the next iteration/cell if newR and newC do not change.
                            if (newR == r && newC == c) {
                                continue;
                            }


                            // Below are for cases where the attempted position is at an Empty or Fire cell.


                            if (board(newR, newC)->isEmpty() && !board(newR, newC)->getNewSpread()) {
                                delete board(newR, newC);       // Deletes the old cell.
                                board(newR, newC) = new Water(newR, newC);       // Assigns a cell to be Water.
                                board(newR, newC)->setNewSpread(true);
                                this->numEmpty--;
                                this->numWater++;
                                continue;
                            }


                            // // If (newR, newC) is a Fire cell.
                            if (board(newR, newC)->isFire() && !board(newR, newC)->getNewSpread()) {
                                delete board(newR, newC);       // Deletes the old cell.
                                board(newR, newC) = new Empty(newR, newC);       // Assigns a cell to be Empty.
                                board(newR, newC)->setNewSpread(true);
                                this->numFire--;
                                this->numEmpty++;
                            }
                        }
                    }
                }
            }            
        }

        
    
};

#endif //_GAMEBOARD_H