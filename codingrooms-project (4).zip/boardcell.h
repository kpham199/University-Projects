// boardcell.h
//
// BoardCell class starter code for course project
// University of Illinois at Chicago
// CS 211 - Programming Practicum
// Original Author: Professor Scott Reckinger
//

#ifndef _BOARDCELL_H
#define _BOARDCELL_H

using namespace std;

// First, the BoardCell abstract base class 

class BoardCell {
	
    public:  
		BoardCell() {} // default contstructor (do nothing)
        virtual ~BoardCell() {} // destructor (do nothing)
        
        virtual char display( ) = 0; // pure virtual function; this is an abstract base class

    	virtual void attemptSpreadTo(size_t& newR, size_t& newC) {
            newR = myRow;
            newC = myCol;
            
        }
        
        virtual void setWind(char inChar ) {}

        // Identifictaion functions
        virtual bool isFire() {return false;}
        virtual bool isWater() {return false;}
        virtual bool isGrass() {return false;}
        virtual bool isWall() {return false;}
        virtual bool isEmpty() {return false;}

        void setRow(size_t r) {myRow = r;}
        size_t getRow() {return myRow;}
        void setCol(size_t c) {myCol = c;}
        size_t getCol() {return myCol;}
        void setPos(size_t r, size_t c) {
            setRow(r);
            setCol(c);
        }

        void setNewSpread(bool u) {newSpread = u;}
        bool getNewSpread() {return newSpread;}

    private:
        size_t myRow; // current row for this board cell in a 2D grid
        size_t myCol; // current column for this board cell in a 2D grid
        
        // newSpread: should be defaulted to false; only true IF this board cell was
        //            updated as a result of a previous spread in the current round;
        bool newSpread; 
}; // BoardCell (abstract base class)


// Then, all the derived classes

class Fire: public BoardCell {
	public:
    	Fire(size_t r, size_t c) {
            setRow(r);
            setCol(c);
            windDir = 's';
        }
        
        virtual char display( ) {
            return '*';
        }
        
        virtual void setWind(char inChar ) {
            windDir = inChar;
        }
    	
        virtual void attemptSpreadTo(size_t& newR, size_t& newC) {
            size_t myRow = this->getRow();
            size_t myCol = this->getCol();


            // Set default values for newR and myRow;
            newR = myRow;
            newC = myCol;


            if (windDir == 'q' || windDir == 'w' || windDir == 'e') {
                newR = myRow - 1;     // Decrement the row when windDir goes up
            }
            if (windDir == 'z' || windDir == 'x' || windDir == 'c') {
                newR = myRow + 1;     // Increment the row when windDir goes down
            }
            if (windDir == 'q' || windDir == 'a' || windDir == 'z') {
                newC = myCol - 1;     // Decrement the column when windDir goes left
            }
             if (windDir == 'e' || windDir == 'd' || windDir == 'c') {
                newC = myCol + 1;     // Increment the column when windDir goes right
            }
        }

        virtual bool isFire() {return true;}

    private:
        char windDir;

}; // Fire

class Water: public BoardCell {
    public:
		Water(size_t r, size_t c) {
            setRow(r);
            setCol(c);
        }

        virtual char display( ) {
            return '~';
        }
        
    	virtual void attemptSpreadTo(size_t& newR,size_t& newC) {
            newR = this->getRow() + (rand() % 3 - 1);
            newC = this->getCol() + (rand() % 3 - 1);
        }

        virtual bool isWater() { return true; }

}; // Water

class Grass: public BoardCell {
	public:
    	Grass(size_t r, size_t c) {
            setRow(r);
            setCol(c);
        }

        virtual char display( ) {
            return ',';
        }

        virtual bool isGrass() { return true; }

}; // Grass

class Wall: public BoardCell {
	public:
    	Wall(size_t r, size_t c) {
            setRow(r);
            setCol(c);
        }

        virtual char display( ) {
            return 'x';
        }
        virtual bool isWall() { return true; }
}; // Wall

class Empty: public BoardCell {
	public:
    	Empty(size_t r, size_t c) {
            setRow(r);
            setCol(c);
        }

        virtual char display( ) {
            return ' ';
        }

        virtual bool isEmpty() { return true; }

}; // Empty

#endif //_BOARDCELL_H
