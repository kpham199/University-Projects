/*-------------------------------------------
Project 5: Fire vs. Water, Part 2
This project is to simulate a turn-based, grid-based
environmental strategy game where the player tries to
spread fire across the landscape of grass, while being
opposed by water that spreads and extinguishes the fire.
Course: CS 211, Spring 2025, UIC
Author: Kalvin Pham
------------------------------------------- */

#pragma once

#include <iostream>
#include <exception>
#include <stdexcept>
#include <algorithm>

using namespace std;

template<typename T>
class Grid {
private:
    struct CELL {
        CELL* Next;
        T Val;
        size_t NumCols;  // total # of columns (0..NumCols-1)
        CELL(CELL* _Next = nullptr, T _Val = T(), size_t _NumCols = 0) {
            Next = _Next;
            Val = _Val;
            NumCols = _NumCols;
        }
    };
    
    size_t NumRows;  // total # of rows (0..NumRows-1)
    CELL** Rows;     // C array of linked lists
public:
    //
    // default constructor:
    //
    // Called automatically by C++ to construct a 4x4 Grid.  All
    // elements are initialized to the default value of T.
    //
    Grid() {
        // initialize 4 rows
        Rows = new CELL*[4];
        NumRows = 4;
        
        // allocate the first cell of the linked list with default value:
        for (size_t r = 0; r < NumRows; ++r) {
            Rows[r] = new CELL(nullptr, T(), 4);
            CELL* cur = Rows[r];
            
            // create the linked list for this row.
            for(size_t c = 1; c < Rows[r]->NumCols; ++c) {
                cur->Next = new CELL(nullptr, T());
                cur = cur->Next;
            }
        }
        
    }
    
    //
    // parameterized constructor:
    //
    // Called automatically by C++ to construct a Grid with R rows,
    // where each row has C columns. All elements are initialized to
    // the default value of T.
    //
    Grid(size_t R, size_t C) {
        // This is where we will create the RxC grid
        NumRows = R; // Setting the number of rows
        Rows = new CELL*[R]; // Allocating space for row pointers on an array
        for (size_t r = 0; r < R; r++){ // Looping through each row
            Rows[r] = new CELL(NULL, T(), C); // Creating the first cell with C columns info
            CELL* current = Rows[r]; // Getting the current row
            for (size_t c = 1; c < C; c++){ // Creating the remaining C-1 cells
                current->Next = new CELL(NULL, T(), C);
                current = current->Next;
            }
        }
    }
    
    //
    // destructor:
    //
    // Called automatically by C++ to free the memory associated by the vector.
    //
    virtual ~Grid() {
        // Here we will free all dynamimcally allocated memory
        for (size_t r = 0; r < NumRows; r++){ // Loop through the rows
            CELL* current = Rows[r]; // Get the current row starting at the first cell
            while(current){ // Traversing the list
                CELL* next = current->Next; // Saving the next pointer
                delete current; // Delete current cell
                current = next; // Then making the current now the next
            }
        }
        delete[] Rows; // Delete the array of row pointers
    }
    
    
    //
    // copy constructor:
    //
    // Called automatically by C++ to construct a Grid that contains a
    // copy of an existing Grid.  Example: this occurs when passing
    // Grid as a parameter by value
    //
    //   void somefunction(Grid<int> G2)  <--- G2 is a copy:
    //   { ... }
    //
    Grid(const Grid<T>& other) {
        NumRows = other.NumRows; // Copying the number of rows
        Rows = new CELL*[NumRows]; // Allocating space for new grid rows into an array
        for (size_t r = 0; r < NumRows; r++){ // Looping through the rows
            CELL* source = other.Rows[r]; // Pointer to the source row
            Rows[r] = new CELL(NULL, source->Val, source->NumCols); // Copying the first cell
            CELL* destination = Rows[r]; // Destination pointer to build new row
            source = source->Next; // Move to the next source cell
            while (source){ // Copying the rest of the row
                destination->Next = new CELL(NULL, source->Val, source->NumCols); // Copying the value
                destination = destination->Next; // Moving the destination pointer forward
                source = source->Next; // Moving the source pointer forward
            }
        }
    }
    
    //
    // copy operator=
    //
    // Called when you assign one vector into another, i.e. this = other;
    //
    Grid& operator=(const Grid& other) {
        if (this == &other) return *this; // Self assignment check

        // Cleaning up the existing data
        this->~Grid();

        // Copy new data
        NumRows = other.NumRows;
        Rows = new CELL*[NumRows];
        for (size_t r = 0; r < NumRows; r++){
            CELL* source = other.Rows[r];
            Rows[r] = new CELL(NULL, source->Val, source->NumCols);
            CELL* destination = Rows[r];
            source = source->Next;
            while (source){
                destination->Next = new CELL(NULL, source->Val, source->NumCols);
                destination = destination->Next;
                source = source->Next;
            }
        }
        return *this;
    }
    
    //
    // numrows
    //
    // Returns the # of rows in the Grid.  The indices for these rows
    // are 0..numrows-1.
    //
    size_t numrows() const {
        
        return NumRows;
    }
    
    
    //
    // numcols
    //
    // Returns the # of columns in row r.  The indices for these columns
    // are 0..numcols-1.  For now, each row will have the same number of columns.
    //
    size_t numcols(size_t r) const {
        if (r >= NumRows) throw out_of_range("Row index out of range.");
        return Rows[r]->NumCols;
    }
    
    
    //
    // size
    //
    // Returns the total # of elements in the grid.
    //
    size_t size() const {
        
        return NumRows * Rows[0]->NumCols;
    }
    
    
    //
    // ()
    //
    // Returns a reference to the element at location (r, c); this
    // allows you to access the element or change it:
    //
    //    grid(r, c) = ...
    //    cout << grid(r, c) << endl;
    //
    T& operator()(size_t r, size_t c) {
        // Access to the rows and columns elements
        if (r >= NumRows) throw out_of_range("Row index out of range.");

        CELL* current = Rows[r];
        size_t colCount = 0;

        // Traverse the linked list to column 'c'
        while(current && colCount < c){
            current = current->Next;
            colCount++;
        }
        if(!current) throw out_of_range("Column index out of range.");
        return current->Val;
    }
    
    //
    // _output
    //
    // Outputs the contents of the grid; for debugging purposes.  This is not
    // tested.
    //
    void _output() {
        // Prints grid contents row-by-row to help debug
        for (size_t r = 0; r < NumRows; r++){
            CELL* current = Rows[r];
            while(current){
                cout << current->Val << " ";
                current = current->Next;
            }
            cout << endl;
        }
    }
    
};
